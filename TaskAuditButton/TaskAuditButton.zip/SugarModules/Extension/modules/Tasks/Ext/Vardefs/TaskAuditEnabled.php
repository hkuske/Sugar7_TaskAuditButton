<?php 
 $GLOBALS["dictionary"]["Task"]["audited"]=true;
